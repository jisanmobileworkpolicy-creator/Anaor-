import express from "express";
import { createClient } from "@supabase/supabase-js";

const app = express();
app.use(express.json({ limit: "1mb" }));

const PORT = process.env.PORT || 3000;
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

const db = SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false }
    })
  : null;

app.get("/", (_req, res) => res.json({
  app: "JISAN MOBILE API",
  status: "ok",
  database: db ? "supabase_configured" : "not_configured"
}));

app.get("/health", async (_req, res) => {
  if (!db) return res.status(503).json({
    status: "needs_configuration",
    database: "not_configured"
  });
  const { error } = await db.from("products").select("id").limit(1);
  if (error) return res.status(503).json({
    status: "database_error",
    message: error.message
  });
  return res.json({ status: "ok", database: "supabase" });
});

function requireDb(_req, res, next) {
  if (!db) return res.status(503).json({
    error: "Backend database is not configured. Set server environment variables."
  });
  next();
}

app.get("/api/products", requireDb, async (req, res) => {
  const category = String(req.query.category || "").trim();
  const search = String(req.query.search || "").trim();
  let query = db.from("products")
    .select("id,name,description,price,image_url,category,stock,created_at")
    .order("created_at", { ascending: false });

  if (category) query = query.eq("category", category);
  if (search) query = query.ilike("name", `%${search.replace(/[%_]/g, "")}%`);

  const { data, error } = await query;
  if (error) return res.status(500).json({ error: "Could not load products." });
  res.json({ products: data || [] });
});

// Admin write endpoints intentionally require a server-side admin token.
// Never put ADMIN_TOKEN or the Supabase service-role key in the APK/client app.
function requireAdmin(req, res, next) {
  const token = process.env.ADMIN_TOKEN;
  if (!token) return res.status(503).json({ error: "Admin access is not configured." });
  const supplied = req.get("x-admin-token");
  if (!supplied || supplied !== token) return res.status(401).json({ error: "Unauthorized." });
  next();
}

app.post("/api/admin/products", requireDb, requireAdmin, async (req, res) => {
  const { id, name, description = "", price, image_url = "", category = "", stock = 0 } = req.body || {};
  if (!id || !name || !Number.isFinite(Number(price)) || Number(price) < 0 ||
      !Number.isInteger(Number(stock)) || Number(stock) < 0) {
    return res.status(400).json({ error: "Valid id, name, non-negative price and integer stock are required." });
  }
  const record = {
    id: String(id).trim(),
    name: String(name).trim(),
    description: String(description),
    price: Number(price),
    image_url: String(image_url),
    category: String(category),
    stock: Number(stock)
  };
  const { data, error } = await db.from("products").upsert(record).select().single();
  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ product: data });
});

app.delete("/api/admin/products/:id", requireDb, requireAdmin, async (req, res) => {
  const { error } = await db.from("products").delete().eq("id", req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ deleted: true });
});

// Store orders without trusting prices sent by the customer. Price is fetched from DB.
app.post("/api/orders", requireDb, async (req, res) => {
  const { customer_name, phone, address, items, note = "" } = req.body || {};
  if (!customer_name || !phone || !address || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Customer name, phone, address and items are required." });
  }
  if (String(customer_name).length > 120 || String(phone).length > 30 ||
      String(address).length > 1000 || String(note).length > 1000 || items.length > 50) {
    return res.status(400).json({ error: "Input is too long." });
  }

  const quantities = new Map();
  for (const item of items) {
    const id = String(item?.product_id || "").trim();
    const quantity = Number(item?.quantity);
    if (!id || !Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
      return res.status(400).json({ error: "Each item needs a product_id and quantity from 1 to 100." });
    }
    quantities.set(id, (quantities.get(id) || 0) + quantity);
  }

  const ids = [...quantities.keys()];
  const { data: products, error: productError } = await db
    .from("products").select("id,name,price,stock").in("id", ids);
  if (productError) return res.status(500).json({ error: "Could not verify products." });
  if (!products || products.length !== ids.length) {
    return res.status(400).json({ error: "One or more products are unavailable." });
  }

  const orderItems = [];
  let total = 0;
  for (const product of products) {
    const quantity = quantities.get(product.id);
    if (Number(product.stock) < quantity) {
      return res.status(409).json({ error: `Insufficient stock for ${product.name}.` });
    }
    const price = Number(product.price);
    total += price * quantity;
    orderItems.push({
      product_id: product.id,
      product_name: product.name,
      unit_price: price,
      quantity,
      line_total: price * quantity
    });
  }

  // Insert order and its lines in one database transaction via the SQL RPC below.
  const { data: result, error } = await db.rpc("create_store_order", {
    p_customer_name: String(customer_name).trim(),
    p_phone: String(phone).trim(),
    p_address: String(address).trim(),
    p_note: String(note),
    p_items: orderItems,
    p_total: Number(total.toFixed(2))
  });
  if (error) return res.status(500).json({ error: "Order could not be saved. Run schema.sql first." });
  res.status(201).json({ order: result });
});

app.listen(PORT, () => {
  console.log(`JISAN MOBILE API listening on ${PORT}`);
});
